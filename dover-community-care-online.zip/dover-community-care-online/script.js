const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle.addEventListener("click", () => {
  mainNav.classList.toggle("open");
});

mainNav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => mainNav.classList.remove("open"));
});

// DEMO: laporan hanya disimpan sementara di browser ini.
// Untuk menerima laporan sungguhan, hubungkan ke backend/database.
let latestDemoCode = "";

document.getElementById("complaintForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const code = "DCC-" + Math.floor(100000 + Math.random() * 900000);
  latestDemoCode = code;
  document.getElementById("formMessage").textContent =
    "Contoh laporan berhasil dibuat. Kode demo Anda: " + code +
    ". Simpan kode ini untuk mencoba fitur pelacakan.";
  this.reset();
});

document.getElementById("trackingForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const entered = document.getElementById("trackingCode").value.trim().toUpperCase();
  const message = document.getElementById("trackingMessage");
  if (latestDemoCode && entered === latestDemoCode) {
    message.textContent = "Status demo: Laporan diterima (simulasi).";
  } else {
    message.textContent = "Kode tidak ditemukan pada sesi browser ini. Coba kirim formulir demo terlebih dahulu.";
  }
});
