DOVER COMMUNITY CARE ONLINE - FILE WEBSITE DEMO

Isi folder:
- index.html : struktur dan isi website
- style.css  : desain website
- script.js  : menu, formulir demo, dan pelacakan demo

CARA MELIHAT:
1. Ekstrak ZIP.
2. Buka folder dover-community-care-online.
3. Klik dua kali index.html untuk melihat website di browser.

CARA UPLOAD KE GITHUB:
1. Buat repository baru di GitHub (Public).
2. Upload index.html, style.css, dan script.js ke root repository.
3. Buka Settings > Pages.
4. Pilih Deploy from a branch, branch main, folder /(root), lalu Save.

CATATAN:
Ini adalah konsep website independen untuk latihan, bukan situs resmi PT Dover Chemical.
Formulir dan pelacakan masih simulasi di browser. Data tidak dikirim ke perusahaan dan tidak tersimpan di server.
